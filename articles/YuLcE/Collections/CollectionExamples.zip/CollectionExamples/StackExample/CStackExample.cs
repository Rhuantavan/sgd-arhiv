using System;
using System.Collections;

namespace StackExample
{
	
	class CStackExample
	{
		
		[STAThread]
		static void Main(string[] args)
		{
			Stack sklad = new Stack(); //ustvarimo nov sklad

			sklad.Push( "Prvi niz" );
			sklad.Push( "Drugi niz" );
			sklad.Push( "Tretji niz" ); //na sklad smo dali 3 nize

			string peekTest = (string)sklad.Peek(); //pogledamo element ki je na vrhu
			Console.WriteLine("Na vrhu je {0}.", peekTest); 

			while (sklad.Count > 0) //iz sklada bomo sprejemali dokler je poln
			{
				String vrh = (string)sklad.Pop(); //vrnemo objekt ki je na vrhu sklada, in ga pobri�emo (type-casting je ponovno nujen, ker Pop() vrne objekt tipa object)
				Console.WriteLine("Na vrhu je bil {0}", vrh);
			}
			
			
			Console.Read();
		}
	}
}
