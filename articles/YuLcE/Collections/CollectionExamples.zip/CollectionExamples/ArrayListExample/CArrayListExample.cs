using System;
using System.Collections; //vklju�imo "namespace" System.Collections

namespace ArrayListExample
{
	

	class CArrayListExample
	{
	
		[STAThread]
		static void Main(string[] args)
		{
			ArrayList dinamicnoPolje = new ArrayList(); //ustvarimo objekt tipa ArrayList
			//1. �elimo vstaviti v na�e novo dinami�no polje neko stati�no polje, ki ga �e imamo:
			Oseba[] poljeOseb = new Oseba[] {new Oseba("Denis", 180, "YuLcE"), new Oseba("Samo",190,"Snake")};
			dinamicnoPolje.AddRange( poljeOseb ); //v seznam smo dodali vse osebe, ki smo jih imeli v stati�nem polju poljeOseb
			//2. dodali bomo novo osebo
			dinamicnoPolje.Add( new Oseba("Peter", 200, "Basket-Man") ); //dodali smo novo besedo v polje

			//3. vrinili bomo �e eno osebo na 2. mesto; indeksi se za�nejo z 0
			dinamicnoPolje.Insert(1, new Oseba("Drugi", 220, "No.2") );

			//izpi�emo podatke o na�i novi strukturi:
			Console.WriteLine("�tevilo oseb v dinamicnoPolje je {0}.\n", dinamicnoPolje.Count );

			//izpi�emo �e vse osebe
			for (int i = 0; i < dinamicnoPolje.Count; i++)
			{
				Console.WriteLine("{0} , {1} cm, {2}", ((Oseba)dinamicnoPolje[i]).Ime,((Oseba)dinamicnoPolje[i]).Visina, ((Oseba)dinamicnoPolje[i]).Vzdevek ); //nad vsakim objektom moramo narediti type-casting, da lahko uporabimo njegove metode (arraylist vrne objekt tipa object)
			}

			Console.Read();//po�akamo, da se program ne zaklju�i
		}
	}
}
