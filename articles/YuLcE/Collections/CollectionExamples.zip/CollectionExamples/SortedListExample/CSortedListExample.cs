using System;
using System.Collections;

namespace SortedListExample
{

	class CSortedListExample
	{

		[STAThread]
		static void Main(string[] args)
		{
		
			SortedList seznamOseb = new SortedList();	//kreiramo nov seznam oseb

			Oseba oseba1 = new Oseba("Kosarkas", 205, "Kosarkas");
			Oseba oseba2 = new Oseba("Denis", 180, "YuLcE");
			Oseba oseba3 = new Oseba("Pritlikavec", 120, "Mali");
			Oseba oseba4 = new Oseba("Samo", 195, "Snake");
			
			//kot klju� za sortiranje bomo uporabljali vi�ino
			seznamOseb.Add( oseba1.Visina, oseba1 );		
			seznamOseb.Add( oseba2.Visina, oseba2 );
			seznamOseb.Add( oseba3.Visina, oseba3 );
			seznamOseb.Add( oseba4.Visina, oseba4 );

			//izpi�emo seznam(ki bo glede na klju�e sortiran)
			for (int i = 0; i < seznamOseb.Count; i++) //ker so podatki v seznamu urejeni jih povrsti izpi�emo
				Console.WriteLine("{0}. {1}", (i+1), seznamOseb.GetByIndex(i)); 


			Console.Read();
		}
	}
}
