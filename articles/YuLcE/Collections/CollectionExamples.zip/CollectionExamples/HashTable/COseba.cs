using System;

namespace HashTableExample
{
	class Oseba
	{
		private string ime;
		private int visina;
		private string vzdevek;

		public Oseba(string _ime, int _visina, string _vzdevek)
		{
			ime = _ime;
			visina = _visina;
			vzdevek = _vzdevek;
		}
		
		public string Ime
		{
			get
			{
				return ime;
			}
		}

		public string Vzdevek
		{
			get
			{
				return vzdevek;
			}
		}

		public int Visina
		{
			get
			{
				return visina;

			}
		}

		public override string ToString()
		{
			try
			{
				return ime+" ("+vzdevek+") "+Convert.ToString(visina);
			}
			catch(Exception)
			{
				
			}
			return ime+" ("+vzdevek+")";
		}


	}
}
