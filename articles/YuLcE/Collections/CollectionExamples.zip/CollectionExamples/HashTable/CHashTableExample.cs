using System;
using System.Collections; //vklju�imo "namespace" System.Collections

namespace HashTableExample
{
	class CHashTableExample
	{
		
		[STAThread]
		static void Main(string[] args)
		{
			//ustvarimo nov Hashtable
			Hashtable ht = new Hashtable();
			//dodamo v hashtable pare KLJU� / OBJEKT
            ht.Add("0", new Oseba("Denis", 180, "YuLcE") );
			ht.Add("1", new Oseba("Samo", 190, "Snake") );
			ht.Add("2", new Oseba("Peter", 200, "BlaBla"));

			//�e �elimo preveriti ali je dolo�en objekt z nekim klju�em v tabeli to storimo tako:
			if (ht.ContainsKey("0") ) Console.WriteLine("Tabela vsebuje objekt s klju�em '0'");
			if (!ht.ContainsKey("10") ) Console.WriteLine("Tabela ne vsebuje objekta s klju�em '10'");

			//�e �elimo iz tabele objekt, ki ima klju� 1 naredimo to tako
			Oseba os = (Oseba)ht["1"]; //ne smemo pozabiti na type-cast druga�e nam Hashtable vrne objekt tipa object!
			Console.WriteLine( "Oseba , ki ima klju� '1' je : " +  os.ToString() );

			//�e �elimo izpisati celotno tabelo (s pomo�je enumeratorja)
			IDictionaryEnumerator en = ht.GetEnumerator();
			while (en.MoveNext())
			{
				Console.WriteLine( en.Key + " = " + en.Value ); //en.Key = klju�, en.Value = objekt(vrednost)
				//opomba: ker izpisujemo se kot vrednost kli�e objekt.toString(), ki smo ga pri razredu overrideali in naredili svoj izpis
			}
			
			Console.Read();
		}
	}
}
