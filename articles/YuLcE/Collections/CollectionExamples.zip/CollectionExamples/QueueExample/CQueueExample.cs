using System;
using System.Collections;

namespace QueueExample
{
	class CQueueExample
	{

		[STAThread]
		static void Main(string[] args)
		{
			Queue blagajna = new Queue(); //ustvarimo objket tipa Queue (vrsta)

			//v vrsto postavimo objekte (v na�em primeru Osebe), kot so pri�li
			blagajna.Enqueue( new Oseba("Denis", 180, "YuLcE"));
			blagajna.Enqueue( new Oseba("Samo", 180, "Snake") );
			blagajna.Enqueue( new Oseba("Peter", 200, "Pero"));

			//kdo je prvi v vrsti?
			Console.WriteLine( "Prvi v vrsti je {0}.", blagajna.Peek() ); //ne rabimo castat, ker smo overrideali toString ;)

			while (blagajna.Count > 0) //ponavljamo dokler je �tevilo objektov v vrsti > 0
			{
				Oseba prva_v_vrsti = (Oseba)blagajna.Dequeue(); //tukaj moramo type-cast narediti; vrsta vrne objekt tipa object
				Console.WriteLine("Naslednji na blagajni: {0}", prva_v_vrsti);
			}
		

			Console.Read();
		}
	}
}
