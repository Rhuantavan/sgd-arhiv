using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using Tao.OpenGl;

namespace OpenGl1
{
	#region MainForm
	/// <summary>
	/// MainForm je nas glavni razred, v katerem bomo zaenkrat (zardi preprostosti) opravljali vecino dela.
	/// Pocasi pa se mu bo pridruzil se kaksen drug.
	/// Nabor metod se z zahtevnostjo naj ne bi spreminjal, saj so le te precej "standardne" (inicializacija,
	/// upodabljanje scene (, posodabljanje scene), branje vhodnih podatkov)
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		/// OglControl bo za nas olajsal kreiranje podrocja kamor bomo renderirali
		/// in ostalih kontekstov, ki sami po sebi zavzamejo clanek ali tri. Kar pa za nas
		/// niti ni bistveno, saj bi radi cim hitreje( it's C#;)) dosegli kaksen efekt.
		private Tao.Platform.Windows.SimpleOpenGlControl OglControl;

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public MainForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.OglControl = new Tao.Platform.Windows.SimpleOpenGlControl();
			this.SuspendLayout();
			// 
			// OglControl
			// 
			this.OglControl.AccumBits = ((System.Byte)(0));
			this.OglControl.AutoCheckErrors = false;
			this.OglControl.AutoFinish = false;
			this.OglControl.AutoMakeCurrent = true;
			this.OglControl.AutoSwapBuffers = true;
			this.OglControl.BackColor = System.Drawing.Color.Black;
			this.OglControl.ColorBits = ((System.Byte)(32));
			this.OglControl.DepthBits = ((System.Byte)(16));
			this.OglControl.Dock = System.Windows.Forms.DockStyle.Fill;
			this.OglControl.Location = new System.Drawing.Point(0, 0);
			this.OglControl.Name = "OglControl";
			this.OglControl.Size = new System.Drawing.Size(312, 206);
			this.OglControl.StencilBits = ((System.Byte)(0));
			this.OglControl.TabIndex = 0;
			this.OglControl.KeyDown += new System.Windows.Forms.KeyEventHandler(this.OnKeyDown);
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(312, 206);
			this.Controls.Add(this.OglControl);
			this.Name = "MainForm";
			this.Text = "OpenGL 2";
			this.ResumeLayout(false);

		}
		#endregion


		#region Main
		/// <summary>
		/// Nezanimivo :P
		/// Vse kar naredi je, da ustvari formo, jo prikaze in zazene naso zanko.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			MainForm mainForm = new MainForm();
			mainForm.Show();
			mainForm.Run();
		}
		#endregion Main

		#region Members
		/// <summary>
		/// Spremenljivke, ki jih bomo uporabljali v aplikaciji.
		/// </summary>

		// spremenljivka, ki jo bomo uporabili za vrtenje nasega trikotnika.
		private float angle = 0.0f;

		#endregion Members


		#region Run
		/// <summary>
		/// Glavna zanka nase aplikacije.
		/// </summary>
		private void Run()
		{
			while (Created) 
			{
				Invalidate(true);				// Osvezi naso celotno formo (poslje Paint sporocili, kar pripravi tudi
												// naso OPenGL kontrolo, da se osvezi)
				Draw();							// Izrise sceno
				Application.DoEvents();			// Poskrbi za vsa sporocila, ki so se morda nabrala med tem loopom (KeyDown, Close, Paint, Resize,.....)

			}
		}
		#endregion Run

		#region Draw
		/// <summary>
		/// Glavno izrisovanje.
		/// </summary>
private void Draw()
{
	/// Izbrise color in depth buffer.
	Gl.glClear(Gl.GL_COLOR_BUFFER_BIT | Gl.GL_DEPTH_BUFFER_BIT);
	/// V trenutno matriko (modelview) nalozi 
	/// identity matriko, kar naso sceno postavi v koordinatno izhodisce.
	Gl.glLoadIdentity();

	/// Premakne sceno za 10 enot v ekran.
	Gl.glTranslatef(0,0,-10);

	/// Zavrti sceno okrog Y osi za kot angle, ki ga vsak frame poveca za 0.1
	Gl.glRotatef(angle, 0,1,0);
	angle +=0.1f;			// povecamo kot
	if(angle>360.0f)		// ce je kot vecji od 360�
		angle = 0.0f;		// ga nastavimo na nic.


	/// Izri�emo en trikotnik
	Gl.glBegin(Gl.GL_TRIANGLES);
	Gl.glColor3f(1, 0, 0);		// prvo oglji�ce je pobarvano rdece...
	Gl.glVertex3f(-1, -1, 0);
	Gl.glColor3f(0, 1, 0);		// drugo zeleno...
	Gl.glVertex3f(1, -1, 0);
	Gl.glColor3f(0, 0, 1);		// tretje pa modro.
	Gl.glVertex3f(0, 1, 0);

	Gl.glEnd();

	/// Nari�imo �e �tiri nepovezane crte.
	Gl.glBegin(Gl.GL_LINES);
	Gl.glVertex3f(3.0f, 0, 0);
	Gl.glVertex3f(5.0f, 0, 0);
	Gl.glVertex3f(3.0f, 1.0f, 0);
	Gl.glVertex3f(5.0f, 1.0f, 0);

	Gl.glVertex3f(-3.0f, 0, 0);
	Gl.glVertex3f(-5.0f, 0, 0);
	Gl.glVertex3f(-3.0f, 1.0f, 0);
	Gl.glVertex3f(-5.0f, 1.0f, 0);
	Gl.glEnd();

	/// Ter nekaj pik.
	Gl.glPointSize(1);
	Gl.glColor3f(0.9f,0.7f,0);	// oran�ne barve
	Gl.glBegin(Gl.GL_POINTS);
	Gl.glVertex3f(0,2,2);
	Gl.glVertex3f(0,2,-2);
	Gl.glEnd();

	/// �e ena malce vecja pika...
	Gl.glPointSize(3);
	Gl.glBegin(Gl.GL_POINTS);
	Gl.glVertex3f(0,2,0);
	Gl.glEnd();


	// Izvrsi vse OpenGL ukaze in s tem spravi vsebino, ki jo zelimo izrisati, na ekran.
	Gl.glFlush();
}
		#endregion Draw

		#region Resize
		/// <summary>
		/// Spreminjanje velikosti OpenGL okna na novo velikost.
		/// </summary>
		private new void Resize(int pWidth, int pHeight)
		{
			Gl.glViewport(0, 0, OglControl.Width, OglControl.Height);		// Nastavi del okna v katerega bomo risali.
			Gl.glMatrixMode(Gl.GL_PROJECTION);								// Kot matriko, ki jo bomo v nadaljevanju urejali izbere projekcijsko matriko.
			Gl.glLoadIdentity();											// Matriko resetira (pomnozi jo z identity matriko).
			Glu.gluPerspective(45,											// Nastavi perspektivno projekcijo.
				((double) OglControl.Width /(double) OglControl.Height),
				0.1, 500);
			Gl.glMatrixMode(Gl.GL_MODELVIEW);								// Kot trenutno matriko izbere modelview matriko.
			Gl.glLoadIdentity();											// Resetira modelview matriko.
		}
		#endregion Resize

		#region Initialize
		/// <summary>
		/// Nekaj klicev nastavitev, ki se izvedejo ob zagonu programa.
		/// </summary>
		private void Initialize()
		{
			/// Nastavi SimpleOpenGLControl (Randy si je izmislil tako dolgo ime:P)
			/// Za nas nastavi vse potrebne nastavitve kontekstov, raznoraznih parametrov, ki jih
			/// je za kar veliko vrstic (poglejte si kaksen C++ & OpenGL tutorial (brez GLUT)).
			OglControl.InitializeContexts();

			/// Nastavi velikost viewportov in perspektivno projekcijo nasega okna.
			OnResize(null);
		}
		#endregion Initialize


		#region Overrides & Handlers

		#region OnLoad
		/// <summary>
		/// Izvede se ob zagonu nase aplikacije.
		/// </summary>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);

			/// Inicializacija OGL kontrole in druge nastavitve.
			Initialize();
		}
		#endregion OnLoad

		#region OnResize
		/// <summary>
		/// Izvede se ob spremembi velikosti okna.
		/// </summary>
		/// <param name="e"></param>
		protected override void OnResize(EventArgs e)
		{
			base.OnResize (e);
			/// spremeni velikost okna.
			Resize(OglControl.Width, OglControl.Height);
		}
		#endregion OnResize

		#region OnKeyDown
		/// <summary>
		/// (handler)
		/// Poskrbi za mozne pritiske tipk.
		/// </summary>
		private void OnKeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			switch(e.KeyCode)
			{
				case Keys.Escape:		/// V primeru, da smo pritisnili Escape
										/// zapre formo.
					Close();
					break;
			}
		}
		#endregion OnKeyDown

		#endregion Overrides

	}
	#endregion MainForm
}
