/* read_ini.cpp - prebere nastavitve iz datoteke. */

/* POPRAVA: funkcija read_line(), kjer se buffer ni sprostil. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TAG_FILENAME "FileName" /* Ime datoteke, ki jo bomo odprli in prebrali del njene vsebine. */
#define TAG_READ_TO  "ReadTo"   /* Stevilo bajtov, ki bomo prebrali iz datoteke */


#define MAX_TAG_LEN  20  /* Maks. velikost oznake. */
#define MAX_VAR_LEN  50  /* Maks. velikost vrednosti. */
#define MAX_LINE_LEN 100 /* Maks. velikost ene vrstice v datoteki. */

/* Privzeta konfiguracijskoa datoteka. */
#define DEFAULT_INIFILE "program_start.ini"

/* Struktura, ki bo vsebovala prebrane informacije iz konf. datoteke. */
struct VARS
{
    char *src_file; /* Datoteka, iz katere bo program bral besedilo. */
    int read_to;    /* Koliko bajtov bo prebral iz datoteke src_file. */
}vars;

/* Polje, ki vsebuje dva niza: prvi je za oznako in drugi je za vrednost. */
char *edited_line[2];

void empty_array();
void read_line(FILE *, char *);
void process_line(char *);
void configure_app();

void empty_array()
{
    /* Postavi vsak prostor v nizu na znak '\0'(null). */
	memset((char *)edited_line[0], '\0', MAX_TAG_LEN);
	memset((char *)edited_line[1], '\0', MAX_VAR_LEN);
}

void read_line(FILE *_stream, char *buffer)
{
	/* Prebrani znak. */
	char znak;
	/* Steje stevilo prebranih znakov. */
	int i = 1;
	/* Ta kazalec bo vseboval prebrano vrstico, brez prelomnega znaka. */
	char *temp = NULL;
    /* Pocistimo buffer z znakom '\0'. */
	memset((char *)buffer, '\0', MAX_LINE_LEN);
	/* Glavna while zanka. */
	while ((znak != '\n'))
	{
		/* Ce je tragicni konec datoteke. */
		if ((znak = fgetc(_stream)) == EOF)
		{
			(* buffer) = 0;
			break;
		}
		/* Pisemo vsak znak posebej v medpomnilnik. */
		buffer[i - 1] = znak;
		/* Povecamo stevilo prebranih znakov. */
		i++;
	}
	/* Doda null-terminated znak. */
	if (buffer != NULL)
		buffer[i - 2] = '\0';
}

void process_line(char *line)
{
    char counter = 0; /* Kazipot za vrstico. */
    char count_var = 0; /* Kazipot za edited_line. */
	char line_size = strlen(line); /* Velikost vrstice(v bajtih)*/

    /* Iscemo oznako. */
    while(line[counter] != '=')
    {
        edited_line[0][counter] = line[counter];
		counter++;
    }
    counter += 1; /* Preskocimo locilni znak. */
    /* Iscemo vrednost. */
    while(line[counter] != '\0')
    {
        edited_line[1][count_var] = line[counter];
		counter++;
		count_var++;
    }
}

void configure_app()
{
	/* Preverja nize. Lahko naredimo tudi tabelo in se po njej 
	   orientiramo. */
    if ((strcmp(edited_line[0], TAG_FILENAME)) == 0) {
		vars.src_file = (char *)malloc((strlen(edited_line[0])));
        strcpy(vars.src_file, edited_line[1]);
	}
    else if ((strcmp(edited_line[0], TAG_READ_TO)) == 0) {
		int temp = atoi(edited_line[1]);
		vars.read_to = temp;
	}
}

int main(int argc, char *argv[])
{

    /* Konfiguracijska datoteka. */
    FILE *setup;
    /* Datoteka, ki bo pozneje prebrana. */
    FILE *msg_file;
    /* Ena vrstica lahko ima maksimalno MAX_LINE_LEN znakov. */
    char *line = (char *) malloc(MAX_LINE_LEN);

    if ((setup = fopen(DEFAULT_INIFILE, "r")) == NULL)
    {
        printf("Napaka pri odpiranju konfiguracijske datoteke \'%s\'!\n", DEFAULT_INIFILE);
        return(-1);
    }
    
    edited_line[0] = (char *)malloc(MAX_TAG_LEN); /* maks. 20 znakov za oznako. */
    edited_line[1] = (char *)malloc(MAX_VAR_LEN); /* maks. 50 znakov za vrednost. */
    
    /* Zanka, ki bo omogocila branje vrstic in nato se njihovo obdelavo. */
    while (!feof(setup))
    {
        memset((char *)line, '\0', MAX_LINE_LEN);
        read_line(setup, line);
        if ((*line) == 0) /* preberemo vrstico. */
			break;
        empty_array();               /* Spraznimo polje edited_line[]. */
        process_line(line);          /* Obdelamo vrstico. */
        configure_app();             /* Nastavi program z nasimi prebranimi nastavitvami. */
    }
	/* Odpre navedeno datoteko v datoteki DEFAULT_INIFILE. */
    if ((msg_file = fopen(vars.src_file, "r")) == NULL)
    {
        printf("Datoteke \'%s\' ni mogoce odpreti!\n", vars.src_file);
        return(-2);
    }
	/* Ker konfiguracijske datoteke ne potrebujemo vec, jo zapremo. */
    fclose(setup);

    /* vars.read_to ne sme biti veccji od datoteke! */
    for(int i = 1; i <= vars.read_to; i++)
    {
        printf("%c", (fgetc(msg_file)));
    }

    /* Zadnje delo, ki ga opravi program preden se konca. */
    fclose(msg_file);
    /* Pocistimo vse rezervirane prostore. */
    free(edited_line[0]);
    free(edited_line[1]);
    free(line);
    return(0);
}
