Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D

Public Class SkinnedModel
    Inherits AllocateHierarchy

    Private mDev As Device

    Private mFrameHierarchy As Frame
    Private mAnimationController As AnimationController

    Private m_pBoneMatrices() As Matrix
    Private m_NumBoneMatricesMax As Integer

    'konstruktor
    Public Sub New(ByVal filename As String, ByVal dev As Device)
        mDev = dev

        Dim aniRoot As AnimationRootFrame
        'nalo�imo model iz file-a
        '(iz neznanega razloga v�asih uspe �ele po nekaj poskusih)
LoadMesh:
        Try
            aniRoot = Mesh.LoadHierarchyFromFile(filename, MeshFlags.Managed, mDev, Me, Nothing)
        Catch ex As Exception
            Debug.WriteLine(ex.Message)
            System.Windows.Forms.Application.DoEvents()
            GoTo LoadMesh
        End Try

        'in si shranimo dobljeni root frame in animation controller
        mFrameHierarchy = aniRoot.FrameHierarchy
        mAnimationController = aniRoot.AnimationController

        'pove�emo mesh z ustreznimi bone-i
        SetupBoneMatrixPointers(mFrameHierarchy)
    End Sub

    Public Overrides Sub SetUserDataInFrame(ByVal frame As Microsoft.DirectX.Direct3D.Frame)
        Dim extra As New FrameExtraData()
        extra.CombinedTransformationMatrix = Matrix.Identity
        frame.UserData = extra
    End Sub

    Public Overrides Sub SetUserDataInMeshContainer(ByVal container As Microsoft.DirectX.Direct3D.MeshContainer)
        Dim a, cBones As Integer
        Dim extra As New MeshExtraData()
        'shranimo si podatke iz containerja v user info
        'nekaterih podatkov si ne bi bilo treba zapomniti, �e bi stvar delala tako kot mora
        'dolo�ene stvari bodo torej odve� ko bo pri�el ven kak�en popravek za managed dx
        extra.Adjacency = container.GetAdjacency
        If Not container.SkinInformation Is Nothing Then extra.SkinInformation = container.SkinInformation.Clone
        container.UserData = extra

        With extra
            'ustvarimo materiale in teksture
            Dim extMaterial() As ExtendedMaterial = container.GetMaterials
            .NumMaterials = extMaterial.Length
            ReDim .Textures(extMaterial.Length - 1)
            ReDim .Materials(extMaterial.Length - 1)
            For a = 0 To extMaterial.Length - 1
                .Textures(a) = TextureLoader.FromFile(mDev, extMaterial(a).TextureFilename)
                .Materials(a) = extMaterial(a).Material3D
                'x modeli nimajo shranjene ambient barve lo�eno od diffuse
                'zato moramo to informacijo sami prekopirati
                .Materials(a).Ambient = .Materials(a).Diffuse
            Next

            '�e gre za skinned mesh
            If Not .SkinInformation Is Nothing Then
                'shranimo si originalni mesh
                .OrigMesh = container.MeshData.Mesh

                'array offset matrik, ki jih potrebujemo za pretvorbo iz
                'model prostora v bone prostor
                cBones = .SkinInformation.NumberBones
                ReDim .BoneOffsetMatrix(cBones - 1)

                'shranimo si offset matrike
                For a = 0 To cBones - 1
                    .BoneOffsetMatrix(a) = .SkinInformation.GetBoneOffsetMatrix(a)
                Next
            End If
        End With
        'pretvorimo splo�ne skinning informacije v hardveru prijazno obliko
        GenerateSkinnedMesh(container)
    End Sub

    Private Sub GenerateSkinnedMesh(ByVal container As MeshContainer)
        '�e ni skinned mesh potem ni kaj za po�eti
        If container.SkinInformation Is Nothing Then Return
        Dim ai, i As Integer
        Dim extra As MeshExtraData
        extra = CType(container.UserData, MeshExtraData)

        'uporabili bomo non-indexed skinning, zato bomo ustvarili izrisljiv mesh
        'z uporabo funkcije ConvertToBlendedMesh

        With extra
            Dim md As MeshData = container.MeshData
            md.Mesh = .SkinInformation.ConvertToBlendedMesh(container.MeshData.Mesh, MeshFlags.Managed Or MeshFlags.OptimizeVertexCache, .Adjacency, Nothing, Nothing, Nothing, .NumInfl, .BoneCombinationTable)
            container.MeshData = md
            .NumAttributeGroups = .BoneCombinationTable.Length

            '�e hardver podpira samo 2 matrix blenda, potem bo treba del mesha izrisati
            's software vertex processingom

            'poi��emo atribut, na katerega upliva preve� bone-ov
            For .AttributeSW = 0 To .NumAttributeGroups - 1
                Dim cInfl As Integer = 0
                Dim iInfl As Integer

                For iInfl = 0 To .NumInfl - 1
                    '�e je BoneId>=0 potem ta atribut uporablja ta bone
                    If .BoneCombinationTable(.AttributeSW).BoneId(iInfl) >= 0 Then
                        cInfl += 1
                    End If
                Next

                If cInfl > mDev.DeviceCaps.MaxVertexBlendMatrices Then Exit For
            Next
            'zdaj .AttributeSW ka�e na prvi index, ki se ga ne da izrisati s HW vertex processingom

            '�e imamo HW in SW, potem moramo dodati Software Processing flag
            If .AttributeSW < .NumAttributeGroups Then
                Dim md2 As MeshData = container.MeshData
                md2.Mesh = container.MeshData.Mesh.Clone(MeshFlags.SoftwareProcessing Or container.MeshData.Mesh.Options.Value, container.MeshData.Mesh.VertexFormat, mDev)
                container.MeshData = md2
            End If

            'za vsak atribut si shranimo koliko blend matrik uporablja
            ReDim .NumBlend(.NumAttributeGroups - 1)
            For ai = 0 To .NumAttributeGroups - 1
                .NumBlend(ai) = 0
                For i = 0 To .NumInfl - 1
                    If .BoneCombinationTable(ai).BoneId(i) > -1 Then .NumBlend(ai) = i
                Next
            Next
        End With
    End Sub

    Private Sub DrawMeshContainer(ByVal MeshContainerBase As MeshContainer, ByVal curFrame As Frame)
        Dim extraMesh As MeshExtraData = CType(MeshContainerBase.UserData, MeshExtraData)
        Dim extraFrame As FrameExtraData = CType(curFrame.UserData, FrameExtraData)
        Dim iMaterial As Integer
        Dim iAttrib As Integer
        Dim AttribIdPrev As Integer
        Dim i As Integer
        Dim numBlend As Integer
        Dim matID As Integer

        Dim iMatrixIndex As Integer
        Dim iPaletteEntry As Integer
        Dim matTemp As Matrix
        Dim maxBlend As Integer = mDev.DeviceCaps.MaxVertexBlendMatrices

        ' najprej preverimo �e sploh uporabljamo skinning
        If Not extraMesh.SkinInformation Is Nothing Then
            With extraMesh
                AttribIdPrev = -1

                'najprej ri�emo z default vertex processingom (tipi�no HW)
                For iAttrib = 0 To .NumAttributeGroups - 1
                    numBlend = .NumBlend(iAttrib)

                    If maxBlend >= numBlend + 1 Then
                        'najprej zra�unamo world matrike za trenutni nabor blend ute�i
                        For i = 0 To .NumInfl - 1
                            iMatrixIndex = .BoneCombinationTable(iAttrib).BoneId(i)
                            If iMatrixIndex > -1 Then
                                matTemp = Matrix.Multiply(.BoneOffsetMatrix(iMatrixIndex), .BoneMatrixData(iMatrixIndex).CombinedTransformationMatrix)
                                mDev.Transform.SetWorldMatrixByIndex(i, matTemp)
                            End If
                        Next

                        'in nastavimo to�no �tevilo blenov
                        mDev.RenderState.VertexBlend = CType(numBlend, VertexBlend)

                        ' nastavimo ustrezen material in teksturo za trenutni subset
                        matID = .BoneCombinationTable(iAttrib).AttribId
                        If ((AttribIdPrev <> matID) OrElse (AttribIdPrev = -1)) Then
                            mDev.Material = .Materials(matID)
                            mDev.SetTexture(0, .Textures(matID))
                            AttribIdPrev = matID
                        End If

                        'vse je nastavljeno za izris
                        MeshContainerBase.MeshData.Mesh.DrawSubset(iAttrib)
                    End If
                Next

                '�e je potrebno izri�emo preostanek s SW
                'na enak na�in kot zgoraj
                If .AttributeSW < .NumAttributeGroups Then
                    AttribIdPrev = -1
                    mDev.SoftwareVertexProcessing = True
                    For iAttrib = .AttributeSW To .NumAttributeGroups - 1
                        numBlend = .NumBlend(iAttrib)

                        If maxBlend < numBlend + 1 Then
                            For i = 0 To .NumInfl - 1
                                iMatrixIndex = .BoneCombinationTable(iAttrib).BoneId(i)
                                If iMatrixIndex > -1 Then
                                    matTemp = Matrix.Multiply(.BoneOffsetMatrix(iMatrixIndex), .BoneMatrixData(iMatrixIndex).CombinedTransformationMatrix)
                                    mDev.Transform.SetWorldMatrixByIndex(i, matTemp)
                                End If
                            Next

                            mDev.RenderState.VertexBlend = CType(numBlend, VertexBlend)

                            matID = .BoneCombinationTable(iAttrib).AttribId
                            If ((AttribIdPrev <> matID) OrElse (AttribIdPrev = -1)) Then
                                mDev.Material = .Materials(matID)
                                mDev.SetTexture(0, .Textures(matID))
                                AttribIdPrev = matID
                            End If

                            MeshContainerBase.MeshData.Mesh.DrawSubset(iAttrib)
                        End If
                    Next
                    mDev.SoftwareVertexProcessing = False
                End If
                mDev.RenderState.VertexBlend = VertexBlend.Disable
            End With
        Else  ' standarden mesh
            mDev.Transform.World = extraFrame.CombinedTransformationMatrix

            For iMaterial = 0 To extraMesh.NumMaterials - 1
                mDev.Material = extraMesh.Materials(iMaterial)
                mDev.SetTexture(0, extraMesh.Textures(iMaterial))
                MeshContainerBase.MeshData.Mesh.DrawSubset(iMaterial)
            Next
        End If
    End Sub

    Private Sub SetupBoneMatrixPointers(ByVal rootFrame As Frame)
        SetupBoneMatrixPointersEx(rootFrame, rootFrame)
    End Sub

    Private Sub SetupBoneMatrixPointersEx(ByVal curFrame As Frame, ByVal rootFrame As Frame)
        With curFrame
            If Not .MeshContainer Is Nothing Then SetupBoneMatrixPointersOnMesh(.MeshContainer, rootFrame)
            If Not .FrameSibling Is Nothing Then SetupBoneMatrixPointersEx(.FrameSibling, rootFrame)
            If Not .FrameFirstChild Is Nothing Then SetupBoneMatrixPointersEx(.FrameFirstChild, rootFrame)
        End With
    End Sub

    Private Sub SetupBoneMatrixPointersOnMesh(ByVal MeshContainerBase As MeshContainer, ByVal rootFrame As Frame)
        Dim iBone, cBones As Integer
        Dim f As Frame
        Dim extra As MeshExtraData = CType(MeshContainerBase.UserData, MeshExtraData)

        '�e imamo skinned mesh mu nastavimo bone matrike
        If Not MeshContainerBase.SkinInformation Is Nothing Then
            cBones = extra.SkinInformation.NumberBones

            ReDim extra.BoneMatrixData(cBones - 1)
            For iBone = 0 To cBones - 1
                f = Frame.Find(rootFrame, extra.SkinInformation.GetBoneName(iBone))
                extra.BoneMatrixData(iBone) = CType(f.UserData, FrameExtraData)
            Next
        End If
    End Sub

    Private Sub DrawFrame(ByVal rootFrame As Frame)
        With rootFrame
            If Not .MeshContainer Is Nothing Then DrawMeshContainer(.MeshContainer, rootFrame)
            If Not .FrameSibling Is Nothing Then DrawFrame(.FrameSibling)
            If Not .FrameFirstChild Is Nothing Then DrawFrame(.FrameFirstChild)
        End With
    End Sub

    Public Sub Draw()
        'rekurziven izris
        DrawFrame(mFrameHierarchy)
    End Sub

    Public Sub Process(ByVal elapsed As Double)
        'animiranje s pomo�jo animation controllerja
        If elapsed > 0 AndAlso Not mAnimationController Is Nothing Then mAnimationController.Time += elapsed
        'update-amo transformacijske matrike
        UpdateFrameMatrices(mFrameHierarchy, Matrix.Identity)
    End Sub

    Private Sub UpdateFrameMatrices(ByVal rootFrame As Frame, ByVal ParentMatrix As Matrix)
        With rootFrame
            DirectCast(.UserData, FrameExtraData).CombinedTransformationMatrix = Matrix.Multiply(rootFrame.TransformationMatrix, ParentMatrix)
            If Not .FrameSibling Is Nothing Then UpdateFrameMatrices(.FrameSibling, ParentMatrix)
            If Not .FrameFirstChild Is Nothing Then UpdateFrameMatrices(.FrameFirstChild, DirectCast(.UserData, FrameExtraData).CombinedTransformationMatrix)
        End With
    End Sub
End Class
