Imports Microsoft.DirectX

Public Class FrameExtraData
    Public CombinedTransformationMatrix As Matrix
End Class
