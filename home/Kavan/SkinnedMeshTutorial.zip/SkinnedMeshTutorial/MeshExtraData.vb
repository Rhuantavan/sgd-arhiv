Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D

Public Class MeshExtraData
    Public NumMaterials As Integer
    Public Textures() As Texture
    Public Materials() As Material
    Public Adjacency() As Integer
    Public SkinInformation As SkinInformation

    'SkinMesh info
    Public NumberBones As Integer
    Public BoneName() As String
    Public OrigMesh As Mesh
    Public AttributeTable() As AttributeRange
    Public NumAttributeGroups As Integer
    Public NumInfl As Integer
    Public BoneCombinationTable() As BoneCombination
    Public BoneMatrixData() As FrameExtraData
    Public BoneOffsetMatrix() As Matrix
    Public NumBlend() As Integer
    Public NumPaletteEntries As Integer
    Public UseSoftwareVP As Boolean
    Public AttributeSW As Integer
End Class
