Imports Microsoft.DirectX
Imports Microsoft.DirectX.Direct3D

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private dev As Device
    Private exitFlag As Boolean 'signal za izhod iz programa

    Private model As SkinnedModel

    Private TimeAtStart As Date
    Private TimeNow As Date
    Private elapsed As Single '�as prete�en v eni zanki
    Private allTime As Single 'celoten prete�en �as v sekundah

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(792, 566)
        Me.Name = "Form1"
        Me.Text = "Skinned Mesh Tutorial (by Kavan)"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'inicializacija dx-a
        'na�eloma bi lahko enumerirali vse kombinacije
        'in izbrali najbolj�o vendar bomo tukaj raje posvetili
        'pozornost drugim stvarem
        Dim presentParams As New PresentParameters()
        With presentParams
            .Windowed = True
            .SwapEffect = SwapEffect.Discard
            .EnableAutoDepthStencil = True
            .AutoDepthStencilFormat = DepthFormat.D16
        End With

        'odlo�itev kak�en VertexProcessing izberemo:
        '�e hardware podpira vsaj 2 VertexBlend matrike potem bomo izbrali Mixed processing
        'in bomo izrisali vso geometrijo, ki ima najve� dva influence bone-a s harversko
        'podporo, preostanek bomo izrisali softversko
        'v primeru da hardver ne podpira vertex blendinga pa bomo vse izrisali v softveru
        Dim info As Caps = Manager.GetDeviceCaps(0, DeviceType.Hardware)
        If info.MaxVertexBlendMatrices >= 2 Then
            dev = New Device(0, DeviceType.Hardware, Me, CreateFlags.MixedVertexProcessing, presentParams)
        Else
            dev = New Device(0, DeviceType.Hardware, Me, CreateFlags.SoftwareVertexProcessing, presentParams)
        End If

        'nalo�imo model
        model = New SkinnedModel(Application.StartupPath & "\tiny.x", dev)

        'nastavimo lu�
        Dim c As Drawing.Color
        dev.RenderState.Ambient = Drawing.Color.FromArgb(0, 255, 255, 255)
        c = Drawing.Color.FromArgb(0, 255, 255, 255)
        With dev.Lights(0)
            .Deferred = True
            .Type = LightType.Directional
            .Direction = New Vector3(1, -2, 1)
            .Direction.Normalize()
            .Diffuse = c
            .Enabled = True
            .Commit()
        End With

        'nastavimo transformacijske matrike
        dev.SetTransform(TransformType.Projection, Matrix.PerspectiveFovLH(60 * System.Math.PI / 180, 800 / 600, 10, 10000))
        dev.SetTransform(TransformType.View, Matrix.LookAtLH(New Vector3(200, 100, -500), New Vector3(0, 0, 0), New Vector3(0, 1, 0)))

        Me.Show()
        Me.Focus()
        TimeAtStart = DateTime.Now
        'glavna zanka v kateri bomo izrisovali
        Do
            With dev
                TimeNow = DateTime.Now
                elapsed = CSng(TimeNow.Subtract(TimeAtStart).TotalSeconds)
                allTime += elapsed
                TimeAtStart = TimeNow

                .Clear(ClearFlags.Target Or ClearFlags.ZBuffer, Color.SkyBlue, 1, 0) '�i��enje zaslona
                .BeginScene()

                'animiramo model
                model.Process(elapsed)

                'izri�emo model
                model.Draw()

                .EndScene()
                .Present() 'prikaz scene
            End With

            Application.DoEvents()
        Loop Until exitFlag
    End Sub

    Private Sub Form1_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        exitFlag = True 'sporo�imo, da prenehamo z izrisom ker zapiramo program
    End Sub
End Class
