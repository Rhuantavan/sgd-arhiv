#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glaux.h>


HDC g_HDC;
float angle;

void Init()
{
	glShadeModel(GL_SMOOTH);
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	glEnable(GL_DEPTH_TEST);
}

void DrawGLScene()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();

	if(angle >=360.0f)
		angle = 0.0f;

	glTranslatef(-1.5f, 0.0f, -7.0f);
	glRotatef(angle, 0.0f, 1.0f, 0.0f);

	glBegin(GL_TRIANGLES);
	  glColor3f(0.0f, 1.0f, 0.0f);
	  glVertex3f(0.0f, 1.0f, 0.0f);
	  glVertex3f(1.0f, 0.0f, 0.0f);
	  glVertex3f(-1.0f, 0.0f, 0.0f);
	glEnd();

	glLoadIdentity();

	glTranslatef(1.5f, 0.0f, -7.0f);
	glRotatef(angle, 1.0f, 0.0f, 1.0f);
	glBegin(GL_QUADS);
	  glColor3f(1.0f, 0.0f, 0.0f);
	  glVertex3f(-1.0f, 1.0f, 0.0f);

	  glColor3f(0.0f, 1.0f, 0.0f);
	  glVertex3f(-1.0f, -1.0f, 0.0f);

	  glColor3f(0.0f, 0.0f, 1.0f);
	  glVertex3f(1.0f, -1.0f, 0.0f);

	  glColor3f(0.5f, 0.0f, 0.6f);
	  glVertex3f(1.0f, 1.0f, 0.0f);
	glEnd();
	

	angle += 0.4f;

	SwapBuffers(g_HDC);
}


void SetupPixelFormat(HDC hDC)
{
	int nPixelFormat;					

	static PIXELFORMATDESCRIPTOR pfd = {
		sizeof(PIXELFORMATDESCRIPTOR),	
		1,							
		PFD_DRAW_TO_WINDOW |		
		PFD_SUPPORT_OPENGL |			
		PFD_DOUBLEBUFFER,				
		PFD_TYPE_RGBA,					
		32,							
		0, 0, 0, 0, 0, 0,				
		0,							
		0,								
		0,								
		0, 0, 0, 0,					
		16,							
		0,								
		0,								
		PFD_MAIN_PLANE,				
		0,							
		0, 0, 0 };						

	nPixelFormat = ChoosePixelFormat(hDC, &pfd);	

	SetPixelFormat(hDC, nPixelFormat, &pfd);		
}

	


LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static HGLRC hRC;
	static HDC   hDC;
	int width, height;

	switch(message)
	{
		case WM_CREATE:				

			hDC = GetDC(hwnd);
			g_HDC = hDC;
			SetupPixelFormat(hDC);

			hRC = wglCreateContext(hDC);
			wglMakeCurrent(hDC, hRC);

			return 0;
			break;

		case WM_CLOSE:				

			wglMakeCurrent(hDC, NULL);
			wglDeleteContext(hRC);

			PostQuitMessage(0);

			return 0;
			break;

		case WM_SIZE:					
			height = HIWORD(lParam);
			width  = LOWORD(lParam);

			if(height == 0)
				height = 1;

			glViewport(0, 0, width, height);
			glMatrixMode(GL_PROJECTION);
			glLoadIdentity();

			gluPerspective(45.0f, (GLfloat)width/(GLfloat)height, 1.0f, 1000.0f);

			glMatrixMode(GL_MODELVIEW);
			glLoadIdentity();

			return 0;
			break;

		default:
			break;
	}

	return (DefWindowProc(hwnd, message, wParam, lParam));
}



int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	WNDCLASSEX windowClass;		
	HWND	   hwnd;			
	MSG		   msg;				
	bool	   done;			


	windowClass.cbSize			= sizeof(WNDCLASSEX);
	windowClass.style			= CS_HREDRAW | CS_VREDRAW;
	windowClass.lpfnWndProc		= WndProc;
	windowClass.cbClsExtra		= 0;
	windowClass.cbWndExtra		= 0;
	windowClass.hInstance		= hInstance;
	windowClass.hIcon			= LoadIcon(NULL, IDI_APPLICATION);			
	windowClass.hCursor			= LoadCursor(NULL, IDC_ARROW);				
	windowClass.hbrBackground	= NULL;		
	windowClass.lpszMenuName	= NULL;										
	windowClass.lpszClassName	= "OpenGL";
	windowClass.hIconSm			= LoadIcon(NULL, IDI_WINLOGO);			


	if (!RegisterClassEx(&windowClass))
		return 0;

	
	hwnd = CreateWindowEx(NULL,								
						  "OpenGL",						
						  "OpenGL tut1 : framework+primitives+colors",	
						  WS_OVERLAPPEDWINDOW | WS_VISIBLE | WS_SYSMENU |
						  WS_SYSMENU | WS_CLIPCHILDREN |	
						  WS_CLIPSIBLINGS,
						  100, 100,							
						  400, 400,							
						  NULL,								
						  NULL,								
						  hInstance,						
						  NULL);							

	if (!hwnd)
		return 0;

	Init();

	ShowWindow(hwnd, SW_SHOW);
	UpdateWindow(hwnd);

	done = false;

	while (!done)
	{
		PeekMessage(&msg, hwnd, NULL, NULL, PM_REMOVE);

		if (msg.message == WM_QUIT)		
			done = true;


		else
		{
            DrawGLScene();
			TranslateMessage(&msg);		
			DispatchMessage(&msg);
		}
	}

	return msg.wParam;
}
